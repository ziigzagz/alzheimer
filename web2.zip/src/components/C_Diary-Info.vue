<template>
  <div class="container">
    <div class="row">
      <div class="col-4">
        <label for="exampleFormControlInput1" class="form-label"
          >หมายเลขผู้ป่วย</label
        >
        <input
          type="email"
          class="form-control"
          id="exampleFormControlInput1"
          placeholder="6030301195"
          disabled
        />
      </div>
      <div class="col-8">
        <label for="exampleFormControlInput1" class="form-label"
          >ชื่อ-สกุล ผู้ป่วย</label
        >
        <input
          type="email"
          class="form-control"
          id="exampleFormControlInput1"
          placeholder="นายอิฟฟาน หะยีอิสมาแอ"
          disabled
        />
      </div>
    </div>

    <div class="row">
      <div class="col-4">
        <label for="exampleFormControlInput1" class="form-label"
          >ชื่อบันทึก</label
        >
        <input
          type="email"
          class="form-control"
          id="exampleFormControlInput1"
          placeholder=""
        />
      </div>
      <div class="col-8">
        <label for="exampleFormControlInput1" class="form-label">เวลา</label>
        <input
          type="email"
          class="form-control"
          id="exampleFormControlInput1"
          placeholder="24/12/2563"
          disabled
        />
      </div>
    </div>
    <div class="row">
      <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label"
          >รายละเอียด</label
        >
        <textarea
          class="form-control"
          id="exampleFormControlTextarea1"
          rows="3"
        ></textarea>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>