<template>
  <div class="container">
    <div class="row">
      <div class="col-4">
        <label for="exampleFormControlInput1" class="form-label">คำแนะนำ</label>
        <input
          type="email"
          class="form-control"
          id="exampleFormControlInput1"
          placeholder=""
        />
      </div>
    </div>
    <div class="row">
      <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label"
          >รายละเอียด</label
        >
        <textarea
          class="form-control"
          id="exampleFormControlTextarea1"
          rows="3"
        ></textarea>
      </div>
    </div>
    <div class="row">
      <div class="col">
        <button class="btn btn-success">สำเร็จ</button>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  
};
</script>

<style>
</style>