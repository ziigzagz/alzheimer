<template>
  <v-card class="mx-auto" height="100%">
    <Login />
  </v-card>
</template>

<script>
import Login from "@/components/C_Login.vue";

export default {
  components: {
    Login
  },
};
</script>

<style>
</style>